import 'package:flutter/material.dart';
import '../../../discovery/discovery_model.dart';
import '../../../remote/brand_detector.dart';

class DeviceListItem extends StatelessWidget {
  final DiscoveredDevice device;
  final bool isConnected;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const DeviceListItem({
    super.key,
    required this.device,
    this.isConnected = false,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme   = Theme.of(context).textTheme;
    final visuals     = _resolveVisuals(device.deviceType, colorScheme);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Card(
        shape: isConnected
            ? RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: const Color(0xFF4CAF50).withValues(alpha: 0.6),
            width: 1.5,
          ),
        )
            : null,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                _DeviceIcon(visuals: visuals),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        device.displayName,
                        style: textTheme.titleSmall?.copyWith(
                          color: colorScheme.onSurface,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      _SupportingText(device: device),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                if (isConnected)
                  const _ConnectedBadge()
                else
                  _BrandOrMethodChip(device: device),
              ],
            ),
          ),
        ),
      ),
    );
  }

  DeviceVisuals _resolveVisuals(DeviceType type, ColorScheme cs) {
    return switch (type) {
      DeviceType.tv      => DeviceVisuals(Icons.tv_rounded, cs.primaryContainer, cs.onPrimaryContainer),
      DeviceType.speaker => DeviceVisuals(Icons.speaker_group_rounded, cs.secondaryContainer, cs.onSecondaryContainer),
      DeviceType.other   => DeviceVisuals(Icons.devices_other_rounded, cs.surfaceContainerHighest, cs.onSurfaceVariant),
    };
  }
}

// =============================================================================

/// Shows brand name if detected, falls back to discovery method.
/// This replaces the old _MethodChip when brand info is available.
class _BrandOrMethodChip extends StatelessWidget {
  final DiscoveredDevice device;
  const _BrandOrMethodChip({required this.device});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme   = Theme.of(context).textTheme;

    final brand = device.detectedBrand;
    final label = (brand != null && brand != TvBrand.unknown)
        ? _brandLabel(brand)
        : _methodLabel(device.method);

    final bool isBrand = brand != null && brand != TvBrand.unknown;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        // Brand chips get a subtle primary tint; method chips stay neutral
        color: isBrand
            ? colorScheme.primaryContainer.withValues(alpha: 0.4)
            : colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isBrand
              ? colorScheme.primary.withValues(alpha: 0.3)
              : colorScheme.outlineVariant,
        ),
      ),
      child: Text(
        label,
        style: textTheme.labelSmall?.copyWith(
          color: isBrand
              ? colorScheme.primary
              : colorScheme.onSurfaceVariant,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
        ),
      ),
    );
  }

  String _brandLabel(TvBrand brand) => switch (brand) {
    TvBrand.samsung   => 'Samsung',
    TvBrand.lg        => 'LG',
    TvBrand.sony      => 'Sony',
    TvBrand.philips   => 'Philips',
    TvBrand.hisense   => 'Hisense',
    TvBrand.tcl       => 'TCL',
    TvBrand.panasonic => 'Panasonic',
    TvBrand.sharp     => 'Sharp',
    TvBrand.toshiba   => 'Toshiba',
    TvBrand.google    => 'Google',
    TvBrand.amazon    => 'Amazon',
    TvBrand.apple     => 'Apple',
    TvBrand.roku      => 'Roku',
    TvBrand.torima   => 'Torima',
    TvBrand.unknown   => 'Unknown',
  };

  String _methodLabel(DiscoveryMethod method) => switch (method) {
    DiscoveryMethod.ssdp         => 'SSDP',
    DiscoveryMethod.mdns         => 'mDNS',
    DiscoveryMethod.networkProbe => 'PROBE',
    DiscoveryMethod.manualIp     => 'IP',
    DiscoveryMethod.qr           => 'QR',
  };
}

// =============================================================================

class _ConnectedBadge extends StatelessWidget {
  const _ConnectedBadge();

  @override
  Widget build(BuildContext context) {
    return const Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _GreenDot(),
        SizedBox(width: 6),
        Text(
          'Connected',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: Color(0xFF4CAF50),
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}

class _GreenDot extends StatelessWidget {
  const _GreenDot();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 8,
      height: 8,
      decoration: const BoxDecoration(
        color: Color(0xFF4CAF50),
        shape: BoxShape.circle,
      ),
    );
  }
}

class _DeviceIcon extends StatelessWidget {
  final DeviceVisuals visuals;
  const _DeviceIcon({required this.visuals});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: visuals.containerColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(visuals.icon, color: visuals.iconColor, size: 24),
    );
  }
}

class _SupportingText extends StatelessWidget {
  final DiscoveredDevice device;
  const _SupportingText({required this.device});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme   = Theme.of(context).textTheme;
    final spans       = <InlineSpan>[];

    if (device.manufacturer != null) {
      spans.add(TextSpan(
        text: device.manufacturer!,
        style: textTheme.bodySmall?.copyWith(
          color: colorScheme.onSurfaceVariant,
          fontWeight: FontWeight.w500,
        ),
      ));
      spans.add(TextSpan(
        text: '  ·  ',
        style: textTheme.bodySmall?.copyWith(color: colorScheme.outline),
      ));
    }
    spans.add(TextSpan(
      text: device.ip,
      style: textTheme.bodySmall?.copyWith(
        color: colorScheme.outline,
        fontFamily: 'monospace',
      ),
    ));

    return RichText(
      text: TextSpan(children: spans),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

class DeviceVisuals {
  final IconData icon;
  final Color containerColor;
  final Color iconColor;
  const DeviceVisuals(this.icon, this.containerColor, this.iconColor);
}