import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:titancast/remote/remote_command.dart';
import 'package:titancast/ui/remote/widgets/remote_button.dart';

class DPadWidget extends StatelessWidget {
  final void Function(RemoteCommand) onCommand;

  const DPadWidget({super.key, required this.onCommand});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    const double size = 240.0;

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // 1. AMBIENT GLOW (Arka Plandaki Gizli Parlama)
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: colorScheme.primary.withValues(alpha: 0.15),
                  blurRadius: 60,
                  spreadRadius: 20,
                ),
              ],
            ),
          ),

          // 2. GLASSMORPHISM (Buzlu Cam Katmanı)
          ClipOval(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  // Yarı saydam çok hafif bir yüzey rengi
                  color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
                  // Premium hissi veren 1 piksellik parlak mikro çerçeve
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.08),
                    width: 1,
                  ),
                ),
              ),
            ),
          ),

          // 3. YÖN TUŞLARI (İkonlar camın üzerinde süzülüyor)
          Positioned(
            top: 6,
            child: _DirectionBtn(
              icon: Icons.keyboard_arrow_up_rounded,
              onTap: () => onCommand(RemoteCommand.up),
            ),
          ),
          Positioned(
            bottom: 6,
            child: _DirectionBtn(
              icon: Icons.keyboard_arrow_down_rounded,
              onTap: () => onCommand(RemoteCommand.down),
            ),
          ),
          Positioned(
            left: 6,
            child: _DirectionBtn(
              icon: Icons.keyboard_arrow_left_rounded,
              onTap: () => onCommand(RemoteCommand.left),
            ),
          ),
          Positioned(
            right: 6,
            child: _DirectionBtn(
              icon: Icons.keyboard_arrow_right_rounded,
              onTap: () => onCommand(RemoteCommand.right),
            ),
          ),

          // 4. MERKEZ ONAY BUTONU (Daha belirgin ve katmanlı)
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: RemoteButton.circle(
              size: 80,
              color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.8),
              onTap: () => onCommand(RemoteCommand.ok),
              child: Icon(Icons.circle, size: 28, color: colorScheme.primary),
            ),
          ),
        ],
      ),
    );
  }
}

class _DirectionBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _DirectionBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return RemoteButton.circle(
      size: 72,
      color: Colors.transparent,
      onTap: onTap,
      child: Icon(
        icon,
        size: 36,
        // İkonların sanki neon tabelaymış gibi hafif parlaması için beyazımsı bir renk kullanıyoruz
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
      ),
    );
  }
}