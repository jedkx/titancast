import 'package:flutter/material.dart';
import 'package:titancast/remote/remote_command.dart';
import 'package:titancast/ui/remote/widgets/remote_button.dart';

/// Paired vertical button groups: Volume (left) and Channel (right) housed in pill shapes.
class VolumeChannelRow extends StatelessWidget {
  final void Function(RemoteCommand) onCommand;

  const VolumeChannelRow({super.key, required this.onCommand});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _RockerPill(
          label: 'VOL',
          topIcon: Icons.add_rounded,
          bottomIcon: Icons.remove_rounded,
          onTop: () => onCommand(RemoteCommand.volumeUp),
          onBottom: () => onCommand(RemoteCommand.volumeDown),
        ),

        // Mute Button (Center)
        RemoteButton.circle(
          size: 56,
          color: colorScheme.errorContainer.withValues(alpha: 0.15),
          onTap: () => onCommand(RemoteCommand.mute),
          child: Icon(Icons.volume_off_rounded, color: colorScheme.error, size: 22),
        ),

        _RockerPill(
          label: 'CH',
          topIcon: Icons.keyboard_arrow_up_rounded,
          bottomIcon: Icons.keyboard_arrow_down_rounded,
          onTop: () => onCommand(RemoteCommand.channelUp),
          onBottom: () => onCommand(RemoteCommand.channelDown),
        ),
      ],
    );
  }
}

class _RockerPill extends StatelessWidget {
  final String label;
  final IconData topIcon;
  final IconData bottomIcon;
  final VoidCallback onTop;
  final VoidCallback onBottom;

  const _RockerPill({
    required this.label,
    required this.topIcon,
    required this.bottomIcon,
    required this.onTop,
    required this.onBottom,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: 64,
      height: 140,
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(
          color: colorScheme.outlineVariant.withValues(alpha: 0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Expanded(
            child: RemoteButton(
              width: double.infinity,
              height: double.infinity,
              color: Colors.transparent,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
              onTap: onTop,
              child: Icon(topIcon, color: colorScheme.onSurface, size: 24),
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
          Expanded(
            child: RemoteButton(
              width: double.infinity,
              height: double.infinity,
              color: Colors.transparent,
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(32)),
              onTap: onBottom,
              child: Icon(bottomIcon, color: colorScheme.onSurface, size: 24),
            ),
          ),
        ],
      ),
    );
  }
}