import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Reusable tappable button for remote controls.
/// Uses [InkWell] for ripple feedback and [HapticFeedback] for tactile response.
class RemoteButton extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;
  final Color color;
  final BorderRadius borderRadius;
  final double width;
  final double height;

  const RemoteButton({
    super.key,
    required this.onTap,
    required this.child,
    required this.color,
    required this.width,
    required this.height,
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
  });

  const RemoteButton.circle({
    super.key,
    required this.onTap,
    required this.child,
    required this.color,
    required double size,
  })  : width = size,
        height = size,
        borderRadius = const BorderRadius.all(Radius.circular(999));

  void _handleTap() {
    HapticFeedback.lightImpact();
    onTap();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Material(
        color: color,
        borderRadius: borderRadius,
        child: InkWell(
          onTap: _handleTap,
          borderRadius: borderRadius,
          child: Center(child: child),
        ),
      ),
    );
  }
}