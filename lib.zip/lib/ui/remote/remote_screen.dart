import 'package:flutter/material.dart';
import 'package:titancast/data/active_device.dart';
import 'package:titancast/discovery/discovery_model.dart';
import 'package:titancast/remote/remote_command.dart';
import 'package:titancast/remote/remote_controller.dart';
import 'package:titancast/ui/remote/widgets/remote_button.dart';
import 'package:titancast/ui/remote/widgets/dpad_widget.dart';
import 'package:titancast/ui/remote/widgets/playback_bar.dart';
import 'package:titancast/ui/remote/widgets/volume_channel_row.dart';

class RemoteScreen extends StatefulWidget {
  const RemoteScreen({super.key});

  @override
  State<RemoteScreen> createState() => _RemoteScreenState();
}

class _RemoteScreenState extends State<RemoteScreen> {
  RemoteController? _controller;
  DiscoveredDevice? _device;

  @override
  void initState() {
    super.initState();
    activeDeviceNotifier.addListener(_onDeviceChanged);
    final current = activeDeviceNotifier.value;
    if (current != null) _attachDevice(current);
  }

  @override
  void dispose() {
    activeDeviceNotifier.removeListener(_onDeviceChanged);
    _controller?.dispose();
    super.dispose();
  }

  void _onDeviceChanged() {
    final current = activeDeviceNotifier.value;
    if (current == null) {
      if (mounted) setState(() => _device = null);
      return;
    }
    if (_device?.ip != current.ip) {
      _attachDevice(current);
    }
  }

  void _attachDevice(DiscoveredDevice d) {
    _controller?.dispose();

    final ctrl = RemoteController(d);

    // HATA ÇÖZÜMÜ: 'ctrl.state.addListener' yerine doğrudan 'ctrl.addListener' kullanıyoruz.
    // Çünkü RemoteController bir ChangeNotifier. Durumu ise '.value' olmadan doğrudan 'ctrl.state' olarak okuyoruz.
    ctrl.addListener(() {
      if (!mounted) return;

      if (ctrl.state == RemoteConnectionState.error) {
        _showTransientStatus('Connection lost. Please try again.', isError: true);
      } else if (ctrl.state == RemoteConnectionState.connected) {
        _showTransientStatus('Connected successfully.');
      }
    });

    setState(() {
      _device = d;
      _controller = ctrl;
    });
    ctrl.connect();
  }

  void _sendCommand(RemoteCommand cmd) {
    _controller?.send(cmd);
  }

  void _showTransientStatus(String message, {bool isError = false}) {
    final colorScheme = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
              color: isError ? colorScheme.onErrorContainer : colorScheme.onPrimaryContainer,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: TextStyle(
                  color: isError ? colorScheme.onErrorContainer : colorScheme.onPrimaryContainer,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? colorScheme.errorContainer : colorScheme.primaryContainer,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  /// Netflix / YouTube butonlarının açıldığı BottomSheet (Pop-up) Menüsü
  void _showAppsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surfaceContainerLow,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 32,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.onSurfaceVariant.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Applications',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _AppChip(
                    label: 'Netflix',
                    color: const Color(0xFFE50914),
                    textColor: Colors.white,
                    onTap: () {
                      Navigator.pop(context);
                      _sendCommand(RemoteCommand.netflix);
                    },
                  ),
                  _AppChip(
                    label: 'YouTube',
                    color: const Color(0xFFFF0000),
                    textColor: Colors.white,
                    onTap: () {
                      Navigator.pop(context);
                      _sendCommand(RemoteCommand.youtube);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      body: CustomScrollView(
        // Kaydırmayı kilitler, ekran her zaman tam oturur
        physics: const NeverScrollableScrollPhysics(),
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 160.0,
            collapsedHeight: 66.0,
            backgroundColor: colorScheme.surface,
            foregroundColor: colorScheme.onSurface,
            surfaceTintColor: colorScheme.surfaceTint,
            shadowColor: Colors.transparent,
            flexibleSpace: LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final top = constraints.biggest.height;
                final safeAreaTop = MediaQuery.of(context).padding.top;
                final minHeight = 66.0 + safeAreaTop;
                final maxHeight = 160.0 + safeAreaTop;
                final expandRatio = ((top - minHeight) / (maxHeight - minHeight)).clamp(0.0, 1.0);

                return Stack(
                  fit: StackFit.expand,
                  children: [
                    Positioned(
                      left: 16,
                      bottom: 16,
                      child: AnimatedOpacity(
                        duration: const Duration(milliseconds: 150),
                        opacity: expandRatio > 0.4 ? 1.0 : 0.0,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'TITANCAST',
                              style: textTheme.labelLarge?.copyWith(
                                color: colorScheme.primary,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.0,
                                fontSize: 15.0,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              'Remote',
                              style: textTheme.headlineSmall?.copyWith(
                                color: colorScheme.onSurface,
                                fontWeight: FontWeight.w400,
                                letterSpacing: -0.3,
                              ),
                            ),
                            const SizedBox(height: 4),
                            if (_device != null)
                              Text(
                                _device!.displayName,
                                style: textTheme.bodyMedium?.copyWith(
                                  color: colorScheme.primary,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                ),
                              )
                            else
                              const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),

                    Positioned(
                      left: 16,
                      right: 16,
                      bottom: 18,
                      child: AnimatedOpacity(
                        duration: const Duration(milliseconds: 150),
                        opacity: expandRatio < 0.4 ? 1.0 : 0.0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Remote',
                              style: textTheme.titleMedium?.copyWith(
                                color: colorScheme.onSurface,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            if (_device != null)
                              Text(
                                _device!.displayName,
                                style: textTheme.labelMedium?.copyWith(
                                  color: colorScheme.primary,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.5,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),

          if (_device == null)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _EmptyState(colorScheme: colorScheme, textTheme: textTheme),
            )
          else
            SliverFillRemaining(
              hasScrollBody: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        RemoteButton.circle(
                          size: 52,
                          color: colorScheme.surfaceContainerHighest,
                          onTap: () => _sendCommand(RemoteCommand.power),
                          child: Icon(Icons.power_settings_new_rounded, color: colorScheme.error, size: 24),
                        ),
                        RemoteButton(
                          width: 80,
                          height: 52,
                          color: colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(26),
                          onTap: _showAppsSheet,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.apps_rounded, color: colorScheme.primary, size: 20),
                              const SizedBox(width: 6),
                              Text(
                                'Apps',
                                style: TextStyle(
                                  color: colorScheme.primary,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    DPadWidget(onCommand: _sendCommand),
                    VolumeChannelRow(onCommand: _sendCommand),
                    PlaybackBar(onCommand: _sendCommand),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _AppChip extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;
  final VoidCallback onTap;

  const _AppChip({
    required this.label,
    required this.color,
    required this.textColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return RemoteButton(
      width: 140,
      height: 56,
      color: color.withValues(alpha: 0.9),
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Text(
        label,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.w700,
          fontSize: 16,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final ColorScheme colorScheme;
  final TextTheme textTheme;

  const _EmptyState({
    required this.colorScheme,
    required this.textTheme,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: colorScheme.secondaryContainer.withValues(alpha: 0.6),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.settings_remote_rounded,
                size: 48,
                color: colorScheme.onSecondaryContainer,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Remote Control',
              style: textTheme.titleLarge?.copyWith(
                color: colorScheme.onSurface,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Connect to a device from the Devices tab\nto use the remote.',
              style: textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}